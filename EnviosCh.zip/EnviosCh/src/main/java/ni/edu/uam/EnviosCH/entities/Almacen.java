package ni.edu.uam.EnviosCH.entities;

import lombok.Getter;
import lombok.Setter;
import org.openxava.annotations.Hidden;
import org.openxava.annotations.ListProperties;
import org.openxava.annotations.Required;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Collection;

@Entity
@Getter @Setter
public class Almacen {
    @Id
    @Hidden
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 50, unique = true)
    @Required
    private String nombre;

    @Column(length = 50)
    private String ubicacion;

    @Required
    private int capacidad;

    @OneToMany(mappedBy = "almacen", cascade = CascadeType.ALL)
    @ListProperties("descripcion, peso, tipoEnvio")
    private Collection<Paquete> paquetes = new ArrayList<>();
}