package ni.edu.uam.EnviosCH.entities;

public enum TipoEnvio {
    EXPRESS,
    ESTANDAR,
    ECONOMICO
}